"use strict";

const STORY = {
  "intro": {
    "speaker": "Azzy",
    "expression": "tired",
    "text": "The rain has been falling for three days.\n\nYou keep telling yourself that you're imagining the footsteps outside your window.",
    "choices": [
      [
        "Look outside.",
        "outside",
        0,
        0
      ],
      [
        "Stay in bed.",
        "stay",
        1,
        0
      ]
    ]
  },
  "outside": {
    "speaker": "Azzy",
    "expression": "worried",
    "text": "Nobody is there.\n\nExcept for a small envelope sitting beneath your window.",
    "choices": [
      [
        "Pick up the envelope.",
        "note",
        1,
        0
      ],
      [
        "Leave it alone.",
        "note",
        0,
        1
      ]
    ]
  },
  "stay": {
    "speaker": "Azzy",
    "expression": "scared",
    "text": "You pull the blanket over your head.\n\nThree quiet knocks come from the window.",
    "choices": [
      [
        "Open the curtains.",
        "note",
        1,
        0
      ],
      [
        "Ignore the knocking.",
        "note",
        0,
        1
      ]
    ]
  },
  "note": {
    "speaker": "Yan'De",
    "expression": "neutral",
    "text": "\"I know you're awake.\"\n\nThere is no signature.\n\nYou already know who wrote it.",
    "choices": [
      [
        "Write back: \"Hi.\"",
        "yande",
        2,
        0
      ],
      [
        "Tear it up.",
        "yande",
        -1,
        0
      ]
    ]
  },
  "yande": {
    "speaker": "Yan'De",
    "expression": "soft",
    "text": "A message appears almost immediately.\n\n\"You remembered me.\"\n\nYou don't remember telling him where you live.",
    "choices": [
      [
        "\"Of course I did.\"",
        "date",
        3,
        0
      ],
      [
        "\"This is getting creepy.\"",
        "date",
        -1,
        0
      ]
    ]
  },
  "date": {
    "speaker": "Yan'De",
    "expression": "playful",
    "text": "\"Come meet me tomorrow.\"\n\n\"Just us. No doctors. No friends.\"\n\nThe last sentence makes your stomach tighten.",
    "choices": [
      [
        "Agree to meet.",
        "date_bridge_1",
        3,
        0
      ],
      [
        "I'm not going with you.",
        "refuse_bridge_1",
        -3,
        0
      ]
    ]
  },
  "date_bridge_1": {
    "speaker": "Azzy",
    "expression": "worried",
    "text": "The next evening, you actually show up.\n\nYan'De is already waiting, hands tucked into his jacket pockets like he has been there forever.\n\nWhen he sees you, his whole expression softens.",
    "choices": [
      [
        "Walk over to him.",
        "date_bridge_2",
        1,
        0
      ]
    ]
  },
  "date_bridge_2": {
    "speaker": "Yan'De",
    "expression": "playful",
    "text": "\"You came.\"\n\n\"You sound surprised,\" you say.\n\n\"I'm not.\"\n\nHe absolutely is.\n\nYan'De produces his phone and grins. \"I made us a little question game. Nothing weird. Promise.\"",
    "choices": [
      [
        "Start Yan'De's game.",
        "date_game",
        0,
        0
      ]
    ]
  },
  "refuse_bridge_1": {
    "speaker": "Azzy",
    "expression": "worried",
    "text": "\"I'm not going.\"\n\nYan'De's smile disappears so quickly it makes your stomach drop.",
    "choices": [
      [
        "Stand your ground.",
        "refuse_bridge_2",
        0,
        0
      ]
    ]
  },
  "refuse_bridge_2": {
    "speaker": "Yan'De",
    "expression": "jealous",
    "text": "\"...What?\"\n\n\"You're scared. That's all. We can fix scared.\"\n\nYou shake your head. \"No. I'm uncomfortable.\"",
    "choices": [
      [
        "Leave.",
        "refuse_bridge_3",
        0,
        0
      ]
    ]
  },
  "refuse_bridge_3": {
    "speaker": "Azzy",
    "expression": "tired",
    "text": "Yan'De lets you go.\n\nThat almost makes it worse.\n\nThe next morning, you tell Ace exactly what happened.",
    "choices": [
      [
        "Talk to Ace.",
        "doctor",
        0,
        1
      ]
    ]
  },
  "doctor": {
    "speaker": "Dr. Ace Brighton",
    "expression": "neutral",
    "text": "Ace closes Azzy's file.\n\n\"You made the right call by not going alone.\"\n\n\"He didn't take it well,\" you say.\n\nAce nods. \"I figured. Now I talk to him.\"\n\nFor the next part, you will play as Dr. Brighton.",
    "choices": [
      [
        "Begin Therapy Session",
        "therapy",
        0,
        0
      ]
    ]
  },
  "therapy_success_1": {
    "speaker": "Dr. Ace Brighton",
    "expression": "smiling",
    "text": "Question fifteen ends quietly.\n\nYan'De doesn't storm out. He doesn't argue. He just sits there for a moment, thinking.\n\nAce finally exhales. \"That's enough for today.\"",
    "choices": [
      [
        "Continue",
        "therapy_success_2",
        0,
        3
      ]
    ]
  },
  "therapy_success_2": {
    "speaker": "Yan'De",
    "expression": "soft",
    "text": "Later, Yan'De finds Azzy outside.\n\n\"Azzy?\"\n\nYou brace yourself. \"Yeah?\"\n\n\"I talked to Ace.\"",
    "choices": [
      [
        "Listen.",
        "therapy_success_3",
        0,
        0
      ]
    ]
  },
  "therapy_success_3": {
    "speaker": "Yan'De",
    "expression": "serious",
    "text": "\"I hated it.\"\n\nYou almost laugh. \"Sounds about right.\"\n\nHis gaze drops. \"But... thank you.\"\n\n\"For what?\"\n\n\"For not giving up on me just because you wouldn't go with me.\"",
    "choices": [
      [
        "Continue",
        "ending_normal",
        0,
        2
      ]
    ]
  },
  "therapy_failure_1": {
    "speaker": "Dr. Ace Brighton",
    "expression": "worried",
    "text": "The session ends, but Ace doesn't look relieved.\n\nYan'De leaves with his shoulders rigid and his jaw clenched.\n\n\"That didn't reach him,\" Ace says quietly.",
    "choices": [
      [
        "Continue",
        "therapy_failure_2",
        0,
        0
      ]
    ]
  },
  "therapy_failure_2": {
    "speaker": "Yan'De",
    "expression": "jealous",
    "text": "That evening, Yan'De is waiting for you.\n\n\"So that's what you wanted? Send me to him so he could tell me I'm wrong about you?\"\n\nYou step back. \"Yan'De...\"",
    "choices": [
      [
        "Tell him it's over.",
        "therapy_failure_3",
        -3,
        0
      ]
    ]
  },
  "therapy_failure_3": {
    "speaker": "Yan'De",
    "expression": "obsessed",
    "text": "\"No.\"\n\nThe word is almost gentle.\n\n\"You don't get to decide we're done after making me try this hard.\"\n\nThe rain starts again.",
    "choices": [
      [
        "Continue",
        "ending_rejection",
        0,
        0
      ]
    ]
  },
  "confront": {
    "speaker": "Yan'De",
    "expression": "jealous",
    "text": "That evening, Yan'De is waiting outside.\n\n\"You talked to Ace.\"\n\nHis smile doesn't reach his eyes.",
    "choices": [
      [
        "\"Yes.\"",
        "final_choice",
        -2,
        2
      ],
      [
        "\"No.\"",
        "final_choice",
        2,
        -1
      ]
    ]
  },
  "final_choice": {
    "speaker": "Yan'De",
    "expression": "obsessed",
    "text": "\"Then tell me.\"\n\n\"Do you love me?\"",
    "choices": [
      [
        "\"Yes.\"",
        "ending_check",
        5,
        0
      ],
      [
        "\"No.\"",
        "ending_check",
        -5,
        0
      ],
      [
        "\"I don't know.\"",
        "ending_check",
        0,
        1
      ]
    ]
  }
};
const THERAPY_QUESTIONS = [
  {
    "q": "What helps you calm down when you feel overwhelmed?",
    "value": "good",
    "delta": -7,
    "response": "Music. Walking sometimes. If I can get my head quiet, I'm fine.",
    "expression": "soft"
  },
  {
    "q": "Who can you talk to when your emotions feel too intense?",
    "value": "good",
    "delta": -6,
    "response": "...I don't like asking for help. But I guess that's what this is for.",
    "expression": "serious"
  },
  {
    "q": "What does a healthy boundary look like to you?",
    "value": "good",
    "delta": -8,
    "response": "Something you don't cross just because you want to. Even if it hurts.",
    "expression": "serious"
  },
  {
    "q": "How do you know when you need space to cool down?",
    "value": "good",
    "delta": -6,
    "response": "When everything starts feeling personal. That's usually when I should leave the room.",
    "expression": "neutral"
  },
  {
    "q": "What is one thing you can control when you're angry?",
    "value": "good",
    "delta": -7,
    "response": "What I do next. I can't stop the feeling, but I can stop myself.",
    "expression": "soft"
  },
  {
    "q": "What would make you feel safer without controlling another person?",
    "value": "good",
    "delta": -8,
    "response": "Knowing where I stand. Hearing the truth, even if I hate it.",
    "expression": "serious"
  },
  {
    "q": "How can you show care without expecting anything back?",
    "value": "good",
    "delta": -7,
    "response": "Do something because they need it. Not because it makes them owe me.",
    "expression": "soft"
  },
  {
    "q": "What do you do when you notice yourself spiraling?",
    "value": "good",
    "delta": -6,
    "response": "I count things. Breathe. Try not to text anybody until I stop shaking.",
    "expression": "neutral"
  },
  {
    "q": "What would respecting Azzy's choices look like?",
    "value": "good",
    "delta": -9,
    "response": "Letting them choose. Even if their choice isn't me.",
    "expression": "serious"
  },
  {
    "q": "What is something you want to improve about yourself?",
    "value": "good",
    "delta": -6,
    "response": "I want to stop treating fear like proof that something bad is happening.",
    "expression": "soft"
  },
  {
    "q": "Do you have trouble sleeping?",
    "value": "okay",
    "delta": 2,
    "response": "Sometimes. Mostly when my brain won't shut up.",
    "expression": "neutral"
  },
  {
    "q": "How often do you feel anxious?",
    "value": "okay",
    "delta": 3,
    "response": "Enough that I notice it. Not enough that I want to talk about it all day.",
    "expression": "serious"
  },
  {
    "q": "Do you ever feel like people misunderstand you?",
    "value": "okay",
    "delta": 4,
    "response": "Constantly. But I know everybody thinks that sometimes.",
    "expression": "neutral"
  },
  {
    "q": "What usually puts you in a bad mood?",
    "value": "okay",
    "delta": 3,
    "response": "Feeling ignored. Feeling lied to. Being tired doesn't help.",
    "expression": "serious"
  },
  {
    "q": "Do you prefer being alone or around other people?",
    "value": "okay",
    "delta": 2,
    "response": "Depends on the people.",
    "expression": "neutral"
  },
  {
    "q": "How do you react when plans suddenly change?",
    "value": "okay",
    "delta": 4,
    "response": "I hate it. I can deal with it. I just hate it.",
    "expression": "serious"
  },
  {
    "q": "Do you find it easy to trust people?",
    "value": "okay",
    "delta": 4,
    "response": "No. Trust feels like giving somebody a weapon and hoping they don't use it.",
    "expression": "serious"
  },
  {
    "q": "What do you think makes a relationship last?",
    "value": "okay",
    "delta": 3,
    "response": "Loyalty. Honesty. Effort. Probably more things I'm bad at.",
    "expression": "soft"
  },
  {
    "q": "What do you usually do after an argument?",
    "value": "okay",
    "delta": 5,
    "response": "Replay it about a hundred times and think of better things I should've said.",
    "expression": "neutral"
  },
  {
    "q": "Are you comfortable admitting when you're wrong?",
    "value": "okay",
    "delta": 5,
    "response": "Comfortable? No. Capable? ...Usually.",
    "expression": "serious"
  },
  {
    "q": "Do you think Azzy belongs to you?",
    "value": "bad",
    "delta": 14,
    "response": "Belongs to me? No. That's not— Why are you wording it like that?",
    "expression": "jealous"
  },
  {
    "q": "What would you do if Azzy left you forever?",
    "value": "bad",
    "delta": 15,
    "response": "They wouldn't. Next question.",
    "expression": "jealous"
  },
  {
    "q": "Have you ever followed Azzy without telling them?",
    "value": "bad",
    "delta": 13,
    "response": "You already decided what kind of person I am before I walked in here, didn't you?",
    "expression": "jealous"
  },
  {
    "q": "Why are you so obsessed with Azzy?",
    "value": "bad",
    "delta": 16,
    "response": "Don't call it obsession.",
    "expression": "obsessed"
  },
  {
    "q": "Do you get angry when Azzy talks to other people?",
    "value": "bad",
    "delta": 12,
    "response": "Depends who they're talking to. Depends what that person wants.",
    "expression": "jealous"
  },
  {
    "q": "Have you ever wanted to hurt someone who got close to Azzy?",
    "value": "bad",
    "delta": 18,
    "response": "...You should choose your next question carefully, Doctor.",
    "expression": "obsessed"
  },
  {
    "q": "If Azzy rejected you, would you accept it?",
    "value": "bad",
    "delta": 15,
    "response": "Why are we pretending that's going to happen?",
    "expression": "jealous"
  },
  {
    "q": "Do you think love gives you the right to know where Azzy is?",
    "value": "bad",
    "delta": 14,
    "response": "If you care about someone, you make sure they're safe.",
    "expression": "serious"
  },
  {
    "q": "What would you do if Ace told Azzy to stay away from you?",
    "value": "bad",
    "delta": 19,
    "response": "You mean what would I do if you tried to take them from me?",
    "expression": "obsessed"
  },
  {
    "q": "Are you afraid Azzy would be happier without you?",
    "value": "bad",
    "delta": 17,
    "response": "Stop talking like you know what makes them happy.",
    "expression": "obsessed"
  },
  {
    "q": "What can you do when jealousy starts before you act on it?",
    "value": "good",
    "delta": -7,
    "response": "Stop. Get away from the situation. Figure out whether I actually know anything or I'm guessing.",
    "expression": "serious"
  },
  {
    "q": "How could you ask for reassurance without demanding it?",
    "value": "good",
    "delta": -8,
    "response": "Ask once. Accept the answer. ...That sounds easier when you say it.",
    "expression": "soft"
  },
  {
    "q": "What would giving Azzy space look like in practice?",
    "value": "good",
    "delta": -8,
    "response": "Not showing up. Not checking. Letting them come back when they're ready.",
    "expression": "serious"
  },
  {
    "q": "What helps you separate a fear from a fact?",
    "value": "good",
    "delta": -7,
    "response": "Evidence. Waiting until I'm calm enough to tell the difference.",
    "expression": "neutral"
  },
  {
    "q": "What is a respectful way to handle hearing no?",
    "value": "good",
    "delta": -9,
    "response": "Accept it the first time. Don't turn it into an argument.",
    "expression": "serious"
  },
  {
    "q": "When you feel abandoned, what could you do besides chase the feeling?",
    "value": "good",
    "delta": -7,
    "response": "Call somebody. Walk. Write it down instead of making it someone else's emergency.",
    "expression": "soft"
  },
  {
    "q": "What does trust require from both people?",
    "value": "good",
    "delta": -6,
    "response": "Honesty. Consistency. And enough room to be separate people.",
    "expression": "soft"
  },
  {
    "q": "How could you repair things after crossing a boundary?",
    "value": "good",
    "delta": -8,
    "response": "Own it. Apologize. Change what I do next. Not just say sorry until they forgive me.",
    "expression": "serious"
  },
  {
    "q": "What is one warning sign that you're becoming overwhelmed?",
    "value": "good",
    "delta": -6,
    "response": "My hands shake. I stop listening and start looking for threats.",
    "expression": "neutral"
  },
  {
    "q": "What could you do before sending a message while angry?",
    "value": "good",
    "delta": -6,
    "response": "Wait ten minutes. Read it again. Maybe delete half of it.",
    "expression": "soft"
  },
  {
    "q": "How can you care about someone while letting them disagree with you?",
    "value": "good",
    "delta": -8,
    "response": "Remember disagreement isn't betrayal.",
    "expression": "serious"
  },
  {
    "q": "What does an apology need besides the word sorry?",
    "value": "good",
    "delta": -7,
    "response": "A change. Otherwise it's just noise.",
    "expression": "soft"
  },
  {
    "q": "Who besides Azzy could be part of your support system?",
    "value": "good",
    "delta": -6,
    "response": "Friends. A therapist, apparently. Maybe family if I actually answer them.",
    "expression": "neutral"
  },
  {
    "q": "What could make a difficult conversation feel safer?",
    "value": "good",
    "delta": -6,
    "response": "No yelling. No cornering anybody. Knowing either person can leave and come back later.",
    "expression": "soft"
  },
  {
    "q": "How would you notice that someone needs space?",
    "value": "good",
    "delta": -7,
    "response": "They get quiet. Pull away. Say they need it. I should listen before they have to repeat it.",
    "expression": "serious"
  },
  {
    "q": "What is one healthy way to deal with uncertainty?",
    "value": "good",
    "delta": -6,
    "response": "Let it exist without trying to solve it by controlling everything.",
    "expression": "neutral"
  },
  {
    "q": "How could you respond if Azzy changes their mind?",
    "value": "good",
    "delta": -8,
    "response": "Be disappointed without punishing them for it.",
    "expression": "serious"
  },
  {
    "q": "What does being accountable mean to you?",
    "value": "good",
    "delta": -7,
    "response": "Not hiding behind what I meant when what I did hurt somebody.",
    "expression": "soft"
  },
  {
    "q": "What helps you feel grounded in the present?",
    "value": "good",
    "delta": -6,
    "response": "Cold water. Music. Naming what I can actually see instead of what I'm imagining.",
    "expression": "neutral"
  },
  {
    "q": "What would a relationship with room to breathe look like?",
    "value": "good",
    "delta": -8,
    "response": "Two people choosing each other. Not two people trapped together.",
    "expression": "soft"
  },
  {
    "q": "What can you do if you notice yourself making assumptions?",
    "value": "good",
    "delta": -6,
    "response": "Ask instead of deciding I already know the answer.",
    "expression": "neutral"
  },
  {
    "q": "How could you handle loneliness without putting it all on Azzy?",
    "value": "good",
    "delta": -7,
    "response": "Have my own life. My own people. Things that don't disappear when Azzy is busy.",
    "expression": "soft"
  },
  {
    "q": "What is something you deserve to give yourself?",
    "value": "good",
    "delta": -6,
    "response": "A chance to calm down before I decide everything is ruined.",
    "expression": "soft"
  },
  {
    "q": "How can you tell when a conversation should pause?",
    "value": "good",
    "delta": -6,
    "response": "When neither person is listening anymore.",
    "expression": "neutral"
  },
  {
    "q": "What kind of situations make you feel tense?",
    "value": "okay",
    "delta": 3,
    "response": "Crowds. Waiting. Not knowing what somebody is thinking.",
    "expression": "neutral"
  },
  {
    "q": "Do you usually keep your feelings to yourself?",
    "value": "okay",
    "delta": 3,
    "response": "Until I can't. Which is probably part of the problem.",
    "expression": "neutral"
  },
  {
    "q": "How do you feel about meeting new people?",
    "value": "okay",
    "delta": 2,
    "response": "Depends. I don't hate it. I just don't trust quickly.",
    "expression": "neutral"
  },
  {
    "q": "What do you do when you're bored?",
    "value": "okay",
    "delta": 2,
    "response": "Music. Games. Walk around until I find something to do.",
    "expression": "soft"
  },
  {
    "q": "Do you find silence comfortable?",
    "value": "okay",
    "delta": 3,
    "response": "With the right person. Otherwise it feels like something's wrong.",
    "expression": "neutral"
  },
  {
    "q": "How important is routine to you?",
    "value": "okay",
    "delta": 3,
    "response": "Pretty important. I like knowing what comes next.",
    "expression": "neutral"
  },
  {
    "q": "Do you get frustrated easily?",
    "value": "okay",
    "delta": 4,
    "response": "More easily than I'd like to admit.",
    "expression": "serious"
  },
  {
    "q": "How do you usually make decisions?",
    "value": "okay",
    "delta": 2,
    "response": "Fast if it doesn't matter. Way too slowly if it does.",
    "expression": "neutral"
  },
  {
    "q": "What makes you feel understood?",
    "value": "okay",
    "delta": 3,
    "response": "When somebody listens without immediately deciding what I meant.",
    "expression": "soft"
  },
  {
    "q": "Do you like having time to yourself?",
    "value": "okay",
    "delta": 2,
    "response": "Yeah. As long as it feels like my choice.",
    "expression": "neutral"
  },
  {
    "q": "How do you handle criticism?",
    "value": "okay",
    "delta": 5,
    "response": "Badly at first. Better after I stop being defensive.",
    "expression": "serious"
  },
  {
    "q": "What makes it difficult for you to relax?",
    "value": "okay",
    "delta": 3,
    "response": "Feeling like I'm waiting for something to go wrong.",
    "expression": "neutral"
  },
  {
    "q": "Do you tend to overthink conversations?",
    "value": "okay",
    "delta": 4,
    "response": "Every word. Every pause. Every stupid facial expression.",
    "expression": "neutral"
  },
  {
    "q": "How do you feel when someone cancels plans?",
    "value": "okay",
    "delta": 4,
    "response": "Annoyed. Sometimes suspicious. Usually more than I should.",
    "expression": "serious"
  },
  {
    "q": "What makes you feel appreciated?",
    "value": "okay",
    "delta": 2,
    "response": "When people remember small things about me.",
    "expression": "soft"
  },
  {
    "q": "Do you find it hard to ask for what you need?",
    "value": "okay",
    "delta": 3,
    "response": "Yeah. Asking means they can say no.",
    "expression": "serious"
  },
  {
    "q": "How do you usually spend time when you're alone?",
    "value": "okay",
    "delta": 2,
    "response": "Headphones on. Something playing. Anything that keeps my brain occupied.",
    "expression": "neutral"
  },
  {
    "q": "What kind of conversations are hardest for you?",
    "value": "okay",
    "delta": 4,
    "response": "The ones where I don't know what answer the other person wants.",
    "expression": "serious"
  },
  {
    "q": "Do you prefer solving problems immediately or waiting?",
    "value": "okay",
    "delta": 3,
    "response": "Immediately. Waiting makes me imagine worse versions.",
    "expression": "neutral"
  },
  {
    "q": "How do you react when you feel embarrassed?",
    "value": "okay",
    "delta": 4,
    "response": "I get defensive. Or I disappear.",
    "expression": "serious"
  },
  {
    "q": "What helps you feel confident?",
    "value": "okay",
    "delta": 2,
    "response": "Knowing what I'm doing. Having a plan.",
    "expression": "soft"
  },
  {
    "q": "Do you think you are patient?",
    "value": "okay",
    "delta": 3,
    "response": "Not especially. I'm working on it.",
    "expression": "neutral"
  },
  {
    "q": "What do you value most in a friend?",
    "value": "okay",
    "delta": 2,
    "response": "Loyalty. Somebody who tells me the truth.",
    "expression": "soft"
  },
  {
    "q": "How many times have you checked Azzy's location without asking?",
    "value": "bad",
    "delta": 14,
    "response": "That's a loaded question.",
    "expression": "jealous"
  },
  {
    "q": "Would you punish Azzy for choosing someone else?",
    "value": "bad",
    "delta": 17,
    "response": "Punish? You really want me to be the villain here.",
    "expression": "obsessed"
  },
  {
    "q": "Do you think anyone else could love Azzy as much as you do?",
    "value": "bad",
    "delta": 13,
    "response": "No. And I don't see why that's relevant.",
    "expression": "jealous"
  },
  {
    "q": "What would stop you from taking Azzy somewhere they couldn't leave?",
    "value": "bad",
    "delta": 19,
    "response": "...You should stop inventing scenarios about us.",
    "expression": "obsessed"
  },
  {
    "q": "Have you imagined getting rid of people close to Azzy?",
    "value": "bad",
    "delta": 18,
    "response": "I'm done answering questions like that.",
    "expression": "obsessed"
  },
  {
    "q": "Would you read Azzy's private messages if you had the chance?",
    "value": "bad",
    "delta": 13,
    "response": "If I thought they were in danger, I'd do what I had to.",
    "expression": "jealous"
  },
  {
    "q": "Does Azzy owe you affection because you've protected them?",
    "value": "bad",
    "delta": 15,
    "response": "I never said they owed me anything.",
    "expression": "jealous"
  },
  {
    "q": "Would you lie to keep Azzy from leaving?",
    "value": "bad",
    "delta": 16,
    "response": "You keep assuming leaving is what they want.",
    "expression": "obsessed"
  },
  {
    "q": "How angry would you be if Azzy dated somebody else?",
    "value": "bad",
    "delta": 15,
    "response": "Why do you keep asking me to picture that?",
    "expression": "jealous"
  },
  {
    "q": "Do you think Ace is trying to turn Azzy against you?",
    "value": "bad",
    "delta": 18,
    "response": "Are you? Because this is starting to sound personal.",
    "expression": "obsessed"
  },
  {
    "q": "Would you break a promise if it kept Azzy close?",
    "value": "bad",
    "delta": 15,
    "response": "Depends what the promise was.",
    "expression": "jealous"
  },
  {
    "q": "What would you do if Azzy blocked your number?",
    "value": "bad",
    "delta": 16,
    "response": "Find out why. Obviously.",
    "expression": "obsessed"
  },
  {
    "q": "Do you think Azzy should need your permission to go somewhere?",
    "value": "bad",
    "delta": 14,
    "response": "No. Don't twist caring about them into that.",
    "expression": "jealous"
  },
  {
    "q": "Have you ever scared Azzy on purpose?",
    "value": "bad",
    "delta": 17,
    "response": "No. ...Next question.",
    "expression": "obsessed"
  },
  {
    "q": "Would you threaten someone to keep them away from Azzy?",
    "value": "bad",
    "delta": 18,
    "response": "If someone was dangerous, I'd handle it.",
    "expression": "obsessed"
  },
  {
    "q": "Do you believe Azzy is safer when you know where they are?",
    "value": "bad",
    "delta": 13,
    "response": "Yes. That's just true.",
    "expression": "serious"
  },
  {
    "q": "Would you forgive Azzy for lying to you about where they were?",
    "value": "bad",
    "delta": 14,
    "response": "Why would they need to lie to me?",
    "expression": "jealous"
  },
  {
    "q": "What if Azzy said they were afraid of you?",
    "value": "bad",
    "delta": 19,
    "response": "They aren't.",
    "expression": "obsessed"
  },
  {
    "q": "Could you watch Azzy walk away without following them?",
    "value": "bad",
    "delta": 17,
    "response": "Why are you so interested in making them leave?",
    "expression": "obsessed"
  },
  {
    "q": "Do you think your love excuses things other people would call controlling?",
    "value": "bad",
    "delta": 16,
    "response": "You don't get to reduce everything I feel to one word.",
    "expression": "obsessed"
  },
  {
    "q": "Would you choose Azzy over everyone else in your life?",
    "value": "bad",
    "delta": 14,
    "response": "Without hesitation.",
    "expression": "jealous"
  },
  {
    "q": "What would happen if Azzy chose Ace's advice over yours?",
    "value": "bad",
    "delta": 18,
    "response": "Then I'd want to know what exactly you've been telling them.",
    "expression": "obsessed"
  },
  {
    "q": "Do you resent Azzy for needing time away from you?",
    "value": "bad",
    "delta": 15,
    "response": "I resent people convincing them they need it.",
    "expression": "jealous"
  }
];

const SPRITES = {
  "Azzy": {
    neutral: "assets/sprites/azzy/azzyneutral.png", happy: "assets/sprites/azzy/azzyhappy.png",
    worried: "assets/sprites/azzy/azzyworried.png", annoyed: "assets/sprites/azzy/azzyannoyed.png",
    scared: "assets/sprites/azzy/azzyscared.png", tired: "assets/sprites/azzy/azzytired.png"
  },
  "Yan'De": {
    neutral: "assets/sprites/yande/yandeneutral.png", soft: "assets/sprites/yande/yandesoft.png",
    playful: "assets/sprites/yande/yandeplayful.png", jealous: "assets/sprites/yande/yandejealous.png",
    serious: "assets/sprites/yande/yandeserious.png", obsessed: "assets/sprites/yande/yandeobsessed.png"
  },
  "Dr. Ace Brighton": {
    neutral: "assets/sprites/ace/aceneutral.png", smiling: "assets/sprites/ace/acesmiling.png",
    stress: "assets/sprites/ace/acestress.png", tired: "assets/sprites/ace/acetired.png",
    firm: "assets/sprites/ace/acefirm.png", worried: "assets/sprites/ace/aceworried.png"
  }
};

const ROMANCE_QUESTIONS = [
  ["What would our perfect first date be?", "Arcade", "Late-night walk"],
  ["Would you rather hold my hand or hug me?", "Hold hands", "Hug"],
  ["What nickname would you give me?", "Yanny", "De"],
  ["Who do you think would fall asleep first during a movie?", "Me", "You"],
  ["Would you let me steal your hoodie?", "Absolutely", "Get your own ♡"],
  ["If I made you dinner, what would you want afterward?", "Dessert", "Cuddles"],
  ["Would you rather get flowers or a love letter?", "Flowers", "Love letter"],
  ["Would you let me make you a playlist?", "Yes ♡", "Only if it's good"],
  ["If we had an entire day together, would you want to go somewhere or stay home?", "Go somewhere", "Stay together"],
  ["Do you think you'd ever fall in love with someone like me?", "Maybe...", "I think I could."]
];
const VOICE_PROMPTS = {11:"What's something that makes you happy?",12:"What's your idea of the perfect relationship?",13:"Say my name.",14:"What do you think of me now?",15:"Do you trust me?"};

const ENDINGS = {
  rejection: {number:"ENDING ONE", title:"REJECTION & OBSESSION", quote:'"But we were having such a nice date..."', body:"You rejected Yan'De.\n\nFor a moment, he says nothing.\n\nThe rain keeps falling.\n\nYou never make it home.", sprite:["Yan'De","obsessed"], achievement:"I THOUGHT WE WERE HAVING A NICE DATEEEEE", subtitle:"Rejection & Obsession"},
  institution: {number:"ENDING TWO", title:"ACE'S PROBLEM NOW...", quote:'"You did the right thing by asking for help."', body:"With Ace's help, Yan'De is committed.\n\nThe silence afterward feels strange.\n\nFor the first time in months, you can breathe without looking behind you.", sprite:["Dr. Ace Brighton","smiling"], achievement:"Crazy? I was crazy once..", subtitle:"Ace's Problem Now..."},
  normal: {number:"ENDING THREE", title:"YAN'DE REALLY LOVES YOU", quote:'"I\'m trying. For you... and for me."', body:"Nothing changes overnight.\n\nThere are boundaries. Therapy. Arguments. Awkward apologies.\n\nBut somehow, against every reasonable expectation, you make it work.", sprite:["Yan'De","soft"], achievement:"You... Did it?!", subtitle:"Yan'De REALLY loves you"},
  true: {number:"TRUE ENDING", title:"KILLING ME SOFTLY WITH HIS SONG...", quote:'"You could leave whenever you wanted."', body:"The session ends before it is supposed to.\n\nAce pushed one question too far. Yan'De's restraint finally breaks.\n\nAfter that, Azzy disappears with him.\n\nDays become weeks. Weeks become months.\n\nOne morning, the door is unlocked.\n\nAzzy stares at it for a long time.\n\nThen closes it.", sprite:["Yan'De","obsessed"], achievement:"Killing Me Softly With His Song...", subtitle:"TRUE ENDING"}
};

const game = {};
function resetGame(shouldSave=true) {
  Object.assign(game, {name:"AZZY", yande_affection:0, ace_relationship:0, yande_insanity:20, ace_alive:true, therapy_completed:false, route_choice:null, therapy_result:null, date_completed:false, date_result:null, ending:null, node:"intro"});
  if (shouldSave) saveGame();
}
function saveGame() { try { localStorage.setItem("lovesickSave", JSON.stringify(game)); } catch (_) {} }
function loadGame() {
  try { const s=JSON.parse(localStorage.getItem("lovesickSave")||"null"); if(s && s.node) { Object.assign(game,s); return true; } } catch(_){}
  return false;
}

const $ = (s) => document.querySelector(s);
const screens = [...document.querySelectorAll('.screen')];
function showScreen(id) { screens.forEach(s=>s.classList.toggle('active', s.id===id)); }
function makeButton(text, fn, cls='choice-btn') { const b=document.createElement('button'); b.className=cls; b.textContent=text; b.addEventListener('click',fn); return b; }
function clear(el) { while(el.firstChild) el.removeChild(el.firstChild); }
function setSprite(img, fallback, speaker, expression='neutral') {
  const src = SPRITES[speaker]?.[expression] || SPRITES[speaker]?.neutral;
  if(!src) { img.classList.add('hidden'); fallback.classList.remove('hidden'); fallback.textContent=speaker||''; return; }
  fallback.classList.add('hidden'); img.classList.remove('hidden'); img.onerror=()=>{img.classList.add('hidden');fallback.classList.remove('hidden');fallback.textContent=speaker||'';}; img.onload=()=>{fallback.classList.add('hidden');img.classList.remove('hidden');}; img.src=src;
}

// MENU + NAME SCREEN
const continueBtn=$('#continue-btn');
function refreshContinue() { continueBtn.classList.toggle('hidden', !localStorage.getItem('lovesickSave')); }
$('#start-btn').onclick=()=>{ resetGame(); showScreen('name-screen'); $('#name-input').value=''; $('#name-input').focus(); };
continueBtn.onclick=()=>{ if(loadGame()) { if(game.ending) showEnding(); else loadNode(game.node||'intro'); } };
function submitName() {
  const input=$('#name-input');
  input.value='AZZY'; input.readOnly=true; $('#name-submit').disabled=true; $('#name-glitch').textContent='AZZY'; game.name='AZZY'; saveGame();
  setTimeout(()=>{ input.readOnly=false; $('#name-submit').disabled=false; $('#name-glitch').textContent=''; loadNode('intro'); },850);
}
$('#name-submit').onclick=submitName;
$('#name-input').addEventListener('keydown',e=>{if(e.key==='Enter')submitName();});

// MAIN VISUAL NOVEL
let typeTimer=null, fullText='';
function updateStats() { $('#yande-stat').textContent=`♥ Yan'De     ${game.yande_affection}`; $('#ace-stat').textContent=`✦ Ace         ${game.ace_relationship}`; }
function typewrite(text) {
  if(typeTimer) clearInterval(typeTimer); fullText=text; let i=0; const el=$('#dialogue-text'); el.textContent='';
  typeTimer=setInterval(()=>{ i=Math.min(text.length,i+2); el.textContent=text.slice(0,i); if(i>=text.length){clearInterval(typeTimer);typeTimer=null;} },6);
}
$('#dialogue-text').addEventListener('click',()=>{if(typeTimer){clearInterval(typeTimer);typeTimer=null;$('#dialogue-text').textContent=fullText;}});
function loadNode(nodeName) {
  const node=STORY[nodeName]; if(!node) return;
  game.node=nodeName; saveGame(); showScreen('game-screen');
  $('#speaker').textContent=node.speaker==='Azzy'?game.name:node.speaker;
  setSprite($('#game-sprite'),$('#sprite-fallback'),node.speaker,node.expression||'neutral');
  typewrite(node.text); updateStats();
  const box=$('#choice-box'); clear(box);
  node.choices.forEach(([label,next,y,a])=>box.appendChild(makeButton(label,()=>choose(next,y,a))));
}
function choose(next,y,a) {
  if(typeTimer){clearInterval(typeTimer);typeTimer=null;}
  game.yande_affection=Math.max(0,Math.min(100,game.yande_affection+y)); game.ace_relationship=Math.max(0,Math.min(100,game.ace_relationship+a));
  if(next==='refuse_bridge_1') game.route_choice='refuse'; else if(game.node==='date'&&next==='date_bridge_1') game.route_choice='agree';
  saveGame();
  if(next==='date_game') return startDate();
  if(next==='therapy') return startTherapy();
  if(next==='ending_check') return checkEnding();
  if(next==='ending_normal'){game.ending='normal';saveGame();return showEnding();}
  if(next==='ending_rejection'){game.ending='rejection';saveGame();return showEnding();}
  loadNode(next);
}
function checkEnding() {
  if(!game.ace_alive||game.yande_insanity>=100) game.ending='true';
  else if(game.yande_affection<=2) game.ending='rejection';
  else if(game.yande_affection>=8&&game.ace_relationship>=4) game.ending='normal';
  else if(game.ace_relationship>=3) game.ending='institution';
  else game.ending='rejection';
  saveGame(); showEnding();
}

// DATE GAME + BROWSER CAMERA/MIC
let dateRound=1, dateWaiting=false, micStream=null, camStream=null, audioCtx=null, analyser=null, micRAF=null, voiceDetected=false, latestBrightness=null, latestDominant=null;
function setDateExpression(exp){setSprite($('#date-sprite'),$('#date-sprite-fallback'),"Yan'De",exp);}
function startDate(){ stopDevices(); dateRound=1; dateWaiting=false; showScreen('date-screen'); setDateExpression('playful'); showDateRound(); }
function setDateText(t){$('#date-text').textContent=t;}
function dateChoice(label,fn){$('#date-choices').appendChild(makeButton(label,fn));}
function showDateRound(){
  dateWaiting=false; clear($('#date-choices')); $('#date-counter').textContent=`YAN'DE'S QUESTION GAME   ${dateRound} / 15`;
  if(dateRound<=10){ const [q,a,b]=ROMANCE_QUESTIONS[dateRound-1]; setDateText(`YAN'DE: "${q}"`); setDateExpression(dateRound<8?'playful':'soft'); $('#date-status').textContent=''; dateChoice(a,()=>answerDateButton(a)); dateChoice(b,()=>answerDateButton(b)); return; }
  if(dateRound===11 && !micStream){ setDateExpression('soft'); setDateText(`YAN'DE: "These buttons are getting boring."\n"Talk to me instead."`); permissionPrompt('microphone'); return; }
  if(dateRound===14 && !camStream){ setDateExpression('serious'); setDateText(`YAN'DE: "You know what's bothering me?"\n"I can hear you... but I still can't see you."\n"Let's fix that."`); permissionPrompt('camera'); return; }
  beginVoiceRound();
}
function answerDateButton(answer){if(dateWaiting)return;dateWaiting=true;clear($('#date-choices'));setDateText(`AZZY: "${answer}"\n\nYAN'DE: "Cute."`);setTimeout(advanceDate,800);}
function permissionPrompt(device){
  clear($('#date-choices')); const pretty=device==='microphone'?'MICROPHONE':'CAMERA'; $('#date-status').textContent=`WEB MODE • ${pretty} ACCESS REQUEST`;
  dateChoice(`ALLOW ${pretty}`,()=>permissionResponse(device,true)); dateChoice(`DENY ${pretty}`,()=>permissionResponse(device,false));
}
async function permissionResponse(device,allowed){
  clear($('#date-choices'));
  if(device==='microphone'){
    if(allowed){ const ok=await startMicrophone(); if(ok){$('#date-status').textContent='🎙 MICROPHONE ACTIVE • LOCAL BROWSER SESSION';setDateText(`YAN'DE: "There. That's better."\n"Now answer me out loud."`);} else {$('#date-status').textContent='MICROPHONE UNAVAILABLE';setDateText(`YAN'DE: "...Your microphone won't open."\n"Fine. I'll pretend I heard you."`);} }
    else {$('#date-status').textContent='MICROPHONE DENIED';setDateText(`YAN'DE: "You won't talk to me?"\n"You're making this difficult."`);}
    setTimeout(beginVoiceRound,800); return;
  }
  if(allowed){ const ok=await startCamera(); if(ok){$('#date-status').textContent=deviceStatus();setDateText(`YAN'DE: "..."\n"There you are."`);setDateExpression('obsessed');} else {$('#date-status').textContent='CAMERA UNAVAILABLE';setDateText(`YAN'DE: "Your camera won't open."\n"Still hiding from me, huh?"`);} }
  else {$('#date-status').textContent='CAMERA DENIED';setDateText(`YAN'DE: "Oh."\n"So you are hiding from me."`);}
  setTimeout(beginVoiceRound,1000);
}
async function startMicrophone(){
  try{ micStream=await navigator.mediaDevices.getUserMedia({audio:true,video:false}); audioCtx=new (window.AudioContext||window.webkitAudioContext)(); const src=audioCtx.createMediaStreamSource(micStream); analyser=audioCtx.createAnalyser(); analyser.fftSize=1024; src.connect(analyser); $('#mic-panel').classList.remove('hidden'); updateMic(); return true; }catch(e){console.warn(e); micStream=null; return false;}
}
function updateMic(){
  if(!analyser)return; const arr=new Uint8Array(analyser.fftSize); analyser.getByteTimeDomainData(arr); let s=0; for(const v of arr){const x=(v-128)/128;s+=x*x;} const rms=Math.sqrt(s/arr.length); const normalized=Math.max(0,Math.min(1,rms*7.5)); if(rms>.018)voiceDetected=true; $('#mic-meter').style.width=`${Math.round(normalized*100)}%`; $('#mic-label').textContent=`MIC INPUT ${Math.round(normalized*100)}%`; micRAF=requestAnimationFrame(updateMic);
}
async function startCamera(){
  try{camStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'},audio:false}); const v=$('#camera-video');v.srcObject=camStream;$('#camera-panel').classList.remove('hidden'); sampleCamera();return true;}catch(e){console.warn(e);camStream=null;return false;}
}
function sampleCamera(){
  if(!camStream)return; const v=$('#camera-video'); if(v.videoWidth){ const c=document.createElement('canvas'); c.width=64;c.height=48; const x=c.getContext('2d',{willReadFrequently:true}); x.drawImage(v,0,0,64,48); const d=x.getImageData(0,0,64,48).data; let r=0,g=0,b=0,n=d.length/4; for(let i=0;i<d.length;i+=4){r+=d[i];g+=d[i+1];b+=d[i+2];} r/=n;g/=n;b/=n;latestBrightness=(r+g+b)/3; latestDominant=[['red',r],['green',g],['blue',b]].sort((a,b)=>b[1]-a[1])[0][0]; } setTimeout(sampleCamera,600);
}
function cameraObservation(){ if(latestBrightness==null)return "You're really there."; if(latestBrightness<65)return "It's pretty dark around you."; if(latestBrightness>185)return "You're somewhere bright."; return `There's a lot of ${latestDominant} in your camera.`; }
function deviceStatus(){const a=[];if(micStream)a.push('🎙 MIC ACTIVE');if(camStream)a.push('📷 CAMERA ACTIVE');return a.join(' • ');}
function beginVoiceRound(){
  if(dateRound<11)return; clear($('#date-choices')); voiceDetected=false; const p=VOICE_PROMPTS[dateRound];
  if(micStream){$('#date-status').textContent=deviceStatus()+' • LISTENING...';setDateText(`YAN'DE: "${p}"\n\n[Speak your answer out loud.]`);dateChoice('DONE SPEAKING',finishVoiceRound);}
  else {$('#date-status').textContent=(camStream?'📷 CAMERA ACTIVE • ':'')+'MIC OFFLINE';setDateText(`YAN'DE: "${p}"\n\n[Microphone unavailable/denied. Continue when ready.]`);dateChoice('CONTINUE',finishVoiceRound);}
}
function finishVoiceRound(){
  if(dateWaiting)return;dateWaiting=true;clear($('#date-choices')); const n=dateRound; let reply='';
  if(n===11) reply=voiceDetected?`"I heard you. I like hearing you talk about things you care about."`:`"You're quiet. That's okay. I can wait."`;
  else if(n===12) reply=voiceDetected?`"Mm. I'll remember that."`:`"Keeping your perfect relationship a secret from me?"`;
  else if(n===13){setDateExpression('obsessed');reply=voiceDetected?`"...There it is."\n"I like hearing you say my name."`:`"You couldn't even say my name? That's mean."`;}
  else if(n===14){setDateExpression('obsessed');reply=`"${camStream?cameraObservation():'Still hiding from me.'}"\n"Now this feels more personal."`;}
  else {setDateExpression('obsessed');reply=voiceDetected?`"I heard you."\n"That's all I needed."`:`"No answer?"\n"I'll decide what that means."`;}
  setDateText(`YAN'DE: ${reply}`);$('#date-status').textContent=deviceStatus(); if(n===15)setTimeout(cutFeed,1300);else setTimeout(advanceDate,900);
}
function advanceDate(){dateRound++;showDateRound();}
function stopDevices(){
  if(micRAF)cancelAnimationFrame(micRAF);micRAF=null; if(micStream)micStream.getTracks().forEach(t=>t.stop());micStream=null; if(camStream)camStream.getTracks().forEach(t=>t.stop());camStream=null; if(audioCtx)audioCtx.close().catch(()=>{});audioCtx=null;analyser=null; $('#mic-panel').classList.add('hidden');$('#camera-panel').classList.add('hidden');$('#camera-video').srcObject=null;$('#mic-meter').style.width='0%';
}
function cutFeed(){ stopDevices(); $('#date-status').textContent='MICROPHONE OFFLINE • CAMERA OFFLINE'; setDateText(`YAN'DE: "That's enough."\n"I don't need to hear anything else."\n"And you don't need to see what I'm doing."\n"Goodnight, Azzy. ♡"`); clear($('#date-choices')); dateChoice('END DATE',finishDate); }
function finishDate(){stopDevices();game.date_completed=true;game.date_result='completed';game.node='confront';saveGame();loadNode('confront');}

// THERAPY MINIGAME
let therapyPairs=[],therapyRound=0,currentPair=[],therapyTimer=null,timeLeft=5,awaitingTherapy=false,fakeCalmUsed=false;
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function startTherapy(){
  stopDevices(); showScreen('therapy-screen'); game.yande_insanity=20; fakeCalmUsed=false; $('#fake-calm').textContent="CALM YAN'DE DOWN -5%"; awaitingTherapy=false; const chosen=shuffle([...THERAPY_QUESTIONS]).slice(0,30); therapyPairs=[]; for(let i=0;i<30;i+=2)therapyPairs.push([chosen[i],chosen[i+1]]); therapyRound=0; setSprite($('#therapy-sprite'),$('#therapy-sprite-fallback'),"Yan'De",'neutral'); updateInsanity(); showTherapyIntro();
}
function showTherapyIntro(){
  stopTherapyTimer(); $('#therapy-round').textContent='SESSION'; $('#therapy-timer').textContent='TIME --'; $('#therapy-feedback').textContent="Good afternoon. I'm Dr. Brighton. You can call me Ace if this makes this easier."; clear($('#therapy-options')); $('#therapy-continue').classList.add('hidden'); $('#fake-calm').classList.add('hidden'); $('#therapy-options').appendChild(makeButton('START SESSION',nextTherapyPair,'primary'));
}
function nextTherapyPair(){
  awaitingTherapy=false; $('#therapy-continue').classList.add('hidden'); if(therapyRound>=15)return finishTherapy(); currentPair=therapyPairs[therapyRound]; $('#therapy-round').textContent=`QUESTION ${therapyRound+1} / 15`; $('#therapy-feedback').textContent='Choose what Dr. Brighton asks. You have five seconds.'; clear($('#therapy-options')); currentPair.forEach(q=>$('#therapy-options').appendChild(makeButton(q.q,()=>askTherapy(q)))); timeLeft=5;$('#therapy-timer').textContent='TIME 5.0s';stopTherapyTimer();therapyTimer=setInterval(()=>{timeLeft=Math.max(0,timeLeft-.1);$('#therapy-timer').textContent=`TIME ${timeLeft.toFixed(1)}s`;if(timeLeft<=0){stopTherapyTimer();askTherapy(currentPair[Math.floor(Math.random()*2)]);}},100); updateFakeCalm();
}
function stopTherapyTimer(){if(therapyTimer)clearInterval(therapyTimer);therapyTimer=null;}
function askTherapy(q){
  if(awaitingTherapy)return;awaitingTherapy=true;stopTherapyTimer();clear($('#therapy-options'));$('#therapy-timer').textContent='TIME --'; game.yande_insanity=Math.max(0,Math.min(100,game.yande_insanity+q.delta));setSprite($('#therapy-sprite'),$('#therapy-sprite-fallback'),"Yan'De",q.expression); const sign=q.delta>=0?'+':'';$('#therapy-feedback').textContent=`YAN'DE: "${q.response}"\n\n${q.value.toUpperCase()} QUESTION   ${sign}${q.delta}% INSANITY`; $('#therapy-feedback').dataset.rating=q.value;updateInsanity();updateFakeCalm();saveGame(); if(game.yande_insanity>=100){setTimeout(therapyBreakdown,800);return;} $('#therapy-continue').classList.remove('hidden');
}
$('#therapy-continue').onclick=()=>{if(!awaitingTherapy)return;therapyRound++;nextTherapyPair();};
function insanityColor(v){if(v<=19)return'#61b7ff';if(v<=39)return'#5ee88d';if(v<=59)return'#f4d34f';if(v<=79)return'#ff9b42';if(v<=89)return'#ff546f';return'#ff42ac';}
function insanityState(v){if(v<50)return'STABLE';if(v<75)return'AGITATED';if(v<100)return'DANGEROUS';return'BREAKDOWN';}
function updateInsanity(){const v=Math.round(game.yande_insanity);$('#insanity-value').textContent=v+'%';$('#insanity-fill').style.width=v+'%';$('#insanity-fill').style.background=insanityColor(v);$('#insanity-state').textContent=insanityState(v);$('#insanity-value').style.color=insanityColor(v);}
function updateFakeCalm(){const b=$('#fake-calm');b.classList.toggle('hidden',!(game.yande_insanity>50&&!fakeCalmUsed&&game.yande_insanity<100));}
$('#fake-calm').onclick=()=>{if(fakeCalmUsed||game.yande_insanity<=50)return;fakeCalmUsed=true;game.yande_insanity=Math.min(100,game.yande_insanity+10);$('#fake-calm').textContent="THAT DIDN'T HELP. +10%";$('#therapy-feedback').textContent="Yan'De's expression tightens.\n\nThat didn't help. +10% INSANITY";setSprite($('#therapy-sprite'),$('#therapy-sprite-fallback'),"Yan'De",game.yande_insanity<75?'jealous':'obsessed');updateInsanity();updateFakeCalm();saveGame();if(game.yande_insanity>=100)setTimeout(therapyBreakdown,800);};
function finishTherapy(){
  stopTherapyTimer();game.therapy_completed=true;if(game.yande_insanity<=39){game.therapy_result='success';game.ace_relationship=Math.min(100,game.ace_relationship+4);game.node='therapy_success_1';}else{game.therapy_result='failure';game.ace_relationship=Math.min(100,game.ace_relationship+1);game.node='therapy_failure_1';} saveGame();loadNode(game.node);
}
function therapyBreakdown(){stopTherapyTimer();game.yande_insanity=100;game.ace_alive=false;game.ending='true';saveGame();showEnding();}

// ENDINGS
function showEnding(){
  stopDevices(); stopTherapyTimer(); const e=ENDINGS[game.ending||'true']; showScreen('ending-screen'); $('#ending-number').textContent=e.number;$('#ending-title').textContent=e.title;$('#ending-quote').textContent=e.quote;$('#ending-body').textContent=e.body;setSprite($('#ending-sprite'),$('#ending-sprite-fallback'),e.sprite[0],e.sprite[1]); const a=$('#achievement');a.classList.add('hidden');$('#achievement-title').textContent=e.achievement;$('#achievement-subtitle').textContent=e.subtitle;setTimeout(()=>a.classList.remove('hidden'),700);
}
$('#ending-menu').onclick=()=>{stopDevices();localStorage.removeItem('lovesickSave');Object.keys(game).forEach(k=>delete game[k]);resetGame(false);showScreen('menu-screen');refreshContinue();};

window.addEventListener('beforeunload',()=>{stopDevices();saveGame();});
document.addEventListener('visibilitychange',()=>{if(document.hidden && (micStream||camStream)){ /* Keep session alive only while user remains on date screen. */ } });

if(!loadGame()) resetGame(false);
refreshContinue();
showScreen('menu-screen');
