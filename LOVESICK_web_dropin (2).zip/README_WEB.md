# LOVESICK — Web Build

This is a browser conversion of the current LOVESICK Kivy build.

## Included

- `index.html` — game screens/UI
- `style.css` — responsive visual-novel styling
- `game.js` — story routing, date minigame, therapy minigame, endings, camera/mic, local save

The web build intentionally keeps the **same sprite paths** as the Python version:

```text
assets/sprites/azzy/...
assets/sprites/yande/...
assets/sprites/ace/...
```

So copy these three web files into the root of your existing LOVESICK project, beside the existing `assets/` folder.

## Test locally

From the LOVESICK project directory:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

Do not open `index.html` directly with `file://` if you want camera/microphone testing. Browser device APIs need a secure context; `localhost` is allowed for local testing, and a deployed site should use HTTPS.

## Camera / microphone behavior

During Yan'De's date game, the browser asks the player for permission before opening either device. The session stays local to the page. The web build:

- shows a live mirrored camera preview when allowed;
- measures microphone volume only (no speech transcription);
- uses only simple frame brightness/dominant-color observations;
- does not save images, video, or audio;
- closes both streams at the end of the date sequence.

## Save data

Progress is stored in browser `localStorage` under `lovesickSave`. The title menu shows **CONTINUE** when a save exists.

## Put it on GitHub

After copying `index.html`, `style.css`, and `game.js` into the repository root:

```bash
git add index.html style.css game.js
git commit -m "Add LOVESICK web build"
git push
```

You can then publish the repository as a static HTTPS site using GitHub Pages or another static host. Camera/microphone permission prompts will work only when the hosting context satisfies browser security rules.
